# Para poder usar la función print e imprimir sin saltos de línea
from __future__ import print_function

import json # Para poder trabajar con objetos JSON
import pprint # Para poder hacer uso de PrettyPrinter
import sys # Para poder usar exit

from elasticsearch import Elasticsearch

def main():
    # Queremos imprimir bonito
    pp = pprint.PrettyPrinter(indent=2)

    # Nos conectamos por defecto a localhost:9200
    es = Elasticsearch()

    results = es.search(
    index = "reddit-mentalhealth",
    body = {
        "size": 0,
        "query": {
            "match": {
                "selftext":"alcoholism"
            }
        },
        "aggs": {
            "Terminos mas significativos": {
                "significant_terms": {
                    "field": "selftext",
                    "size": 5,
                    "gnd": {}
                }
            }
        }
    }
    )

    posts = []
    for i in range (5):
        posts.append(results['aggregations']['Terminos mas significativos']['buckets'][i]['key'])

    resultsList = []
    for i in range (len(posts)):
        results = es.search(
            index = "reddit-mentalhealth",
            body = {
                "size": 0,
                "query": {
                   "bool": {
                        "must": [{
                            "match": {
                                "selftext" : posts[i],
                             }},
                             {"match": {
                                "selftext": "alcoholism"
                             }
                         }]
                   }
              },
                "aggs": {
                    "Terminos mas significativos": {
                        "significant_terms": {
                            "field": "selftext",
                            "size": 5,
                            "gnd": {}
                        }
                    }
                }
            }
         )
        resultsList.append(results)

    print("RESULTADOS DE LA CONSULTA EXPANDIDA")
    for i in range (len(posts)):
        for j in range (len(resultsList[i]['aggregations']['Terminos mas significativos']['buckets'])):
            print(resultsList[i]['aggregations']['Terminos mas significativos']['buckets'][j])

if __name__ == '__main__':
    main()