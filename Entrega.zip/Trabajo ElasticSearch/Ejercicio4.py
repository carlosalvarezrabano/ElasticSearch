
from __future__ import print_function
from elasticsearch import Elasticsearch
import json
import pprint
import sys


def main():

    pp = pprint.PrettyPrinter(indent=1)
    es = Elasticsearch()


    print ("--- Palabras encontradas con diagnosed with para gente que habla de suicidio ---")

    results = es.search(
        index = "reddit-mentalhealth",
        body = {
            "size": 0,
            "size": 0,
            "query": {
                "match": {
                    "selftext":"\"killing myself\""
                }
            },
            "aggs": {
                "Terminos mas significativos": {
                    "significant_terms": {
                        "field": "author",
                        "size": 100
                    }
                }
            }
        }
     )

    users = []
    for i in range (100):
        users.append(results['aggregations']['Terminos mas significativos']['buckets'][i]['key'])

    resultsList = []
    for i in range (len(users)):
        results = es.search(
            index = "reddit-mentalhealth",
            body = {
                "size": 0,
                "size": 0,
                "query": {
                   "bool": {
                        "must": [{
                            "match": {
                                "author" : users[i],
                             }},
                             {"match": {
                                "selftext": "diagnosed with"
                             }
                         }]
                   }
              },
                "aggs": {
                    "Terminos mas significativos": {
                        "significant_terms": {
                            "field": "selftext",
                            "size": 10
                        }
                    }
                }
            }
         )
        resultsList.append(results)

    for i in range (len(users)):
        for j in range (len(resultsList[i]['aggregations']['Terminos mas significativos']['buckets'])):
            print(resultsList[i]['aggregations']['Terminos mas significativos']['buckets'][j]['key'])


    print ("--- Palabras encontradas con diagnosed with para gente que habla de auto lesiones ---")


    results = es.search(
        index = "reddit-mentalhealth",
        body = {
            "size": 0,
            "size": 0,
            "query": {
                "match": {
                    "selftext":"\"self harm\""
                }
            },
            "aggs": {
                "Terminos mas significativos": {
                    "significant_terms": {
                        "field": "author",
                        "size": 10
                    }
                }
            }
        }
     )

    users = []
    for i in range (10):
        users.append(results['aggregations']['Terminos mas significativos']['buckets'][i]['key'])

    resultsList = []
    for i in range (len(users)):
        results = es.search(
            index = "reddit-mentalhealth",
            body = {
                "size": 0,
                "size": 0,
                "query": {
                   "bool": {
                        "must": [{
                            "match": {
                                "author" : users[i],
                             }},
                             {"match": {
                                "selftext": "sick"
                             }
                         }]
                   }
              },
                "aggs": {
                    "Terminos mas significativos": {
                        "significant_terms": {
                            "field": "selftext",
                            "size": 10
                        }
                    }
                }
            }
         )
        resultsList.append(results)

    for i in range (len(users)):
        for j in range (len(resultsList[i]['aggregations']['Terminos mas significativos']['buckets'])):
            print(resultsList[i]['aggregations']['Terminos mas significativos']['buckets'][j]['key'])
if __name__ == '__main__':
    main()
