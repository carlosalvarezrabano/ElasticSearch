
from __future__ import print_function
from elasticsearch import Elasticsearch
import json
import pprint
import sys


def main():

    pp = pprint.PrettyPrinter(indent=1)
    es = Elasticsearch()

    results = es.search(
        index = "reddit-mentalhealth",
        body = {
            "size": 0,
            "query": {
                 "query_string": {
                 "default_field": "selftext",
                    "query":  "\"mg of\" AND \"take\"" ,
                   }
	         },
             "aggs": {
                "Buscando nombres de medicamentos...": {
                    "significant_terms": {
                        "field": "selftext",
                        "size": 200,
                        "gnd":{}
                        }
                    }
                }
        }
     )

    for i in range (len(results['aggregations']['Buscando nombres de medicamentos...']['buckets'])):
        print(results['aggregations']['Buscando nombres de medicamentos...']['buckets'][i]['key'])


if __name__ == '__main__':
    main()

